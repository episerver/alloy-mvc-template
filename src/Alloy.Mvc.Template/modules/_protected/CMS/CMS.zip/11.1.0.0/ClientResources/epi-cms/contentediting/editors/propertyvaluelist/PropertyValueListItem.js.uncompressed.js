require({cache:{
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/PropertyValueListItem.html':"<div class=\"epi-card epi-card--numbered epi-card--mini\">\n    <div class=\"dijitInline dojoDndHandle\">\n        <span class=\"dijitInline epi-iconDnD\">\n        </span>\n    </div>\n    <div class=\"dijitInline epi-mo\" data-dojo-attach-point=\"containerNode\"></div>\n    <span class=\"dijitInline dijitIcon epi-iconContextMenu\"></span>\n</div>\n"}});
﻿define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueListItem", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",
    "epi/shell/widget/_FocusableMixin",
    // resources
    "dojo/text!./templates/PropertyValueListItem.html"
], function (
    // dojo
    declare,
    // dijit
    _WidgetBase,
    _Container,
    _TemplatedMixin,
    _FocusableMixin,
    // resources
    template
) {
    return declare([_WidgetBase, _Container, _TemplatedMixin, _FocusableMixin], {
        // summary:
        //      The view for the PropertyValueListItem. Responsible for setting
        //      the editor and handle focus
        // tags:
        //      internal

        templateString: template,

        focus: function () {
            this.editor.focus && this.editor.focus();
        },

        addChild: function (child) {
            // summary:
            //      Override the add child to be able to set the local editor instance

            this.inherited(arguments);

            this.editor = child;
        }
    });
});
