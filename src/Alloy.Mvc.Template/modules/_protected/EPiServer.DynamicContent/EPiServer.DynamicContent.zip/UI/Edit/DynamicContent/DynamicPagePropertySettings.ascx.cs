using System;
using System.Text;
using EPiServer.Configuration;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DynamicContent;
using EPiServer.DynamicContent.PlugIn;
using EPiServer.Web.WebControls;
using EPiServer.ServiceLocation;

namespace EPiServer.UI.Edit.DynamicContent
{
    /// <summary>
    /// A settings UI for the dynamic adapter DynamicPageProperty
    /// </summary>
    public partial class DynamicPagePropertySettings : DynamicContentEditControl
    {
        internal Injected<IContentLoader> ContentLoader { get; set; }

        /// <summary>
        /// Attaches to the ValueChaged event and sets up the input controls.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"/> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            PageLink.ValueChanged += new EventHandler(DisplayControl_TextChanged);

            if (!IsPostBack)
            {
                PageReference dynamicLink = ((DynamicPageProperty)DynamicContent).ContentLink.ToPageReference();
                PageLink.PageLink = dynamicLink;
                if (!PageReference.IsNullOrEmpty(dynamicLink))
                {
                    PopulateDropDownList(dynamicLink);
                }
            }
        }

        /// <summary>
        /// Repopulates the drop down when the value for the InputPageReference is changed.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void DisplayControl_TextChanged(object sender, EventArgs e)
        {
            PopulateDropDownList(PageLink.PageLink);
        }

        /// <summary>
        /// Populates the drop down list with all the properties avaliable for a certain page.
        /// </summary>
        /// <param name="pageLink">A reference to the page to list PropertyData from.</param>
        private void PopulateDropDownList(PageReference pageLink)
        {
            StringBuilder pageTypeProperties = new StringBuilder();
            StringBuilder dynamicProperties = new StringBuilder();
            StringBuilder metaDataProperties = new StringBuilder();

            PageData page = null;

            try
            {
                if (!PageReference.IsNullOrEmpty(pageLink))
                {
                    page = ContentLoader.Service.Get<PageData>(pageLink);
                }
            }
            catch(ContentNotFoundException)
            {
                // E.g. if the page has been deleted
            }

            if (!PageReference.IsNullOrEmpty(pageLink) && page != null)
            {
                PropertyPanel.Visible = true;

                // We populate the dropdown by building the HTML ourself.
                // The reason for that is that there is no support for optgroups in asp:DropDownList.
                pageTypeProperties.AppendFormat("<optgroup label=\"{0}\">", Translate("/edit/dynamiccontent/DynamicPagePropertysettings/pagetypeproperties"));
                metaDataProperties.AppendFormat("<optgroup label=\"{0}\">", Translate("/edit/dynamiccontent/DynamicPagePropertysettings/metadataproperties"));

                string selected;
                string language;
                bool isSelected = false;
                // Go through all the page type and meta data properties. The Dynamic properties are not included in the collection, they are handled seperatly.
                foreach (PropertyData prop in page.Property)
                {
                    // Certain built in properties should be ignored.
                    if (PropertyShouldBeIgnored(prop))
                    {
                        continue;
                    }

                    selected = String.Empty;
                    if (!isSelected && ((DynamicPageProperty)DynamicContent).PropertyName == prop.Name)
                    {
                        selected = " selected=\"selected\"";
                        isSelected = true;
                    }

                    if (prop.IsPropertyData)
                    {
                        pageTypeProperties.AppendFormat("<option value=\"{0}\"{2}>{1}</option>", Server.HtmlEncode(prop.Name), Server.HtmlEncode(prop.TranslateDisplayName()), selected);
                    }
                    else
                    {
                        metaDataProperties.AppendFormat("<option value=\"{0}\"{2}>{1}</option>", Server.HtmlEncode(prop.Name), Server.HtmlEncode(prop.TranslateDisplayName()), selected);
                    }
                }

                if (Settings.Instance.OperationCompatibility.HasFlag(EPiServerCompatibility.DynamicProperties))
                {
                    dynamicProperties.AppendFormat("<optgroup label=\"{0}\">", Translate("/edit/dynamiccontent/DynamicPagePropertysettings/dynamicproperties"));

                    foreach (DynamicProperty dynProp in DynamicProperty.ListForPage(PageReference.StartPage))
                    {
                        selected = language = String.Empty;
                        if (!isSelected && ((DynamicPageProperty)DynamicContent).PropertyName == dynProp.PropertyValue.Name)
                        {
                            selected = " selected=\"selected\"";
                            isSelected = true;
                        }
                        //If the property exists in more than one language, only add one
                        if (string.IsNullOrEmpty(dynProp.LanguageBranch) || dynProp.LanguageBranch == page.Language.Name)
                            dynamicProperties.AppendFormat("<option value=\"{0}\"{2}>{1}{3}</option>", Server.HtmlEncode(dynProp.PropertyValue.Name), Server.HtmlEncode(dynProp.TranslateDisplayName()), selected, language);
                    }

                    dynamicProperties.Append("</optgroup>");
                }


                pageTypeProperties.Append("</optgroup>");
                metaDataProperties.Append("</optgroup>");
            }
            else
            {
                PropertyPanel.Visible = false;
            }

            // We want an empty option first, then a list in the order page type properties, dynamic properties and meta data properties.
            PropertyListItems.Text = String.Format("<option value=\"\"></option>{0}{1}{2}", pageTypeProperties.ToString(), dynamicProperties.ToString(), metaDataProperties.ToString());
        }

        /// <summary>
        /// Copies the values from the input controls to the dynamic content before a save is made.
        /// </summary>
        public override void PrepareForSave()
        {
            // Validate that both a page and a property on that page are selected
            if (PageReference.IsNullOrEmpty(PageLink.PageLink))
            {
                Page.Validators.Add(new StaticValidator(Translate("/edit/dynamiccontent/dynamicpagepropertysettings/pagelinkerror")));
                return;
            }
            if (String.IsNullOrEmpty(Request["PropertyList"]))
            {
                Page.Validators.Add(new StaticValidator(Translate("/edit/dynamiccontent/dynamicpagepropertysettings/propertylisterror")));
                return;
            }
            // Take the values from the input controls and assign them to the dynamic content
            ((DynamicPageProperty)DynamicContent).ContentLink = PageLink.PageLink;
            ((DynamicPageProperty)DynamicContent).PropertyName = Request["PropertyList"];
        }

        private bool PropertyShouldBeIgnored(PropertyData property)
        {
            return property.Name == MetaDataProperties.PageTargetFrame ||
                property.Name == MetaDataProperties.PageChangedOnPublish;
        }
    }
}
