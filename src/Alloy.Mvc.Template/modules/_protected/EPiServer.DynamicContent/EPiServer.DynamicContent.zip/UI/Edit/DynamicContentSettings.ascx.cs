using EPiServer.DynamicContent;

namespace EPiServer.UI.Edit
{
    /// <summary>
    /// The generic settings control used for the dynamic content dialog.
    /// </summary>
    public partial class DynamicContentSettings : DynamicContentEditControl
    {
        /// <summary>
        /// Initializes this control by setting up the data for the PropertyDataForm.
        /// </summary>
        public void Initialize()
        {
            if (this.DynamicContent != null)
            {
                SettingsForm.Data = DynamicContent.Properties;
            }
        }

        /// <summary>
        /// Calls SetValuesForPropertyControls on the PageBase to move the data to the PropertyDataCollection of the dynamic content.
        /// </summary>
        public override void PrepareForSave()
        {
            var webFormsBase = Page as EditContentWebFormsBase;
            if (webFormsBase != null)
            {
                webFormsBase.SetValuesForPropertyControls(this);
                return;
            }
        }
    }
}