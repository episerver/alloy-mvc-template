﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using EPiServer.Core.Html.StringParsing;
using EPiServer.DynamicContent;
using EPiServer.HtmlParsing;
using EPiServer.Shell.WebForms;
using EPiServer.Web;

namespace EPiServer.UI.Editor.Dialogs
{
    public partial class DynamicContentPreview : WebFormsBase
    {
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            MasterPageFile = null;
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            string postedText = Request.Form["DynamicContent"];
            if (string.IsNullOrEmpty(postedText))
            {
                return;
            }
            string textContents = Sanitize(postedText);

            Control previewControl = CreateDynamicContentPreview(textContents);

            if (previewControl != null)
            {
                Form.Controls.Add(previewControl);
            }

            foreach (string cssUrl in ContentCssUrls())
            {
                RegisterCSSFile(cssUrl, cssUrl);
            }      
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            RewritePipe rewritePipe;
            this.Response.Filter = Global.UrlRewriteProvider.GetHtmlRewriter().GetRewriteFilter(new UrlBuilder(Request.Url), new UrlBuilder(Request.Url), Context.Response.ContentEncoding, Response.Filter, out rewritePipe);
        }

        private Control CreateDynamicContentPreview(string textContents)
        {
            IFragmentParser parser = Locate.Advanced.GetInstance<IFragmentParser>();
            var controlResolver = Locate.Advanced.GetInstance<IStringFragmentControlResolver>();

            var fragments = parser.Parse(textContents, FragmentParserMode.LeaveMappedLinks, true);
            
            DynamicContentFragment dynamicContentFragment = fragments[0] as DynamicContentFragment;
            if (dynamicContentFragment == null)
            {
                return null;
            }

            IDynamicContentCustomPreview customPreview = dynamicContentFragment.DynamicContent as IDynamicContentCustomPreview;
            Control previewControl;

            if (customPreview != null)
            {
                string previewHtml = customPreview.CreateFullBlownPreview();
                //It's important to check against null and not String.Empty since this means that you want to have an empty preview
                //while null falls back to external creation of dynamic content.
                if (previewHtml != null)
                {
                    previewControl = new Literal() { Text = previewHtml };
                    return previewControl;
                }
            }
            return controlResolver.GetControl(dynamicContentFragment, this);
        }

        protected IEnumerable<string> ContentCssUrls()
        {
            if(!string.IsNullOrEmpty(Request["content_css"]))
            {
                foreach (string cssUrl in Request["content_css"].Split(','))
                {
                    yield return ResolveUrl(Server.HtmlEncode(cssUrl));
                }
            }
        }

        static ElementToken[] acceptedElementTokens = new[] { ElementToken.Span, ElementToken.P, ElementToken.Div };
        static string[] acceptedAttributes = new[] { 
            "class", 
            "contenteditable", 
            DynamicContentFragment.HashAttributeName, 
            DynamicContentFragment.StateAttributeName, 
            DynamicContentFragment.DynamicClassAttributeName, 
            FragmentHandlerHelper.ClassIdAttributeName 
        };
        
        private string Sanitize(string possiblyUnsafeHtml)
        {
            using (var writer = new StringWriter())
            {
                var reader = new HtmlStreamReader(possiblyUnsafeHtml);

                foreach (var fragment in reader)
                {
                    switch (fragment.FragmentType)
                    {
                        case HtmlFragmentType.Element:
                            ElementFragment element = (ElementFragment)fragment;
                            if (acceptedElementTokens.Contains(element.Token))
                            {
                                for (int i = element.Attributes.Count - 1; i >= 0; i--)
                                {
                                    if (!acceptedAttributes.Any(a => element.Attributes[i].NameEquals(a)))
                                    {
                                        element.Attributes.RemoveAt(i);
                                    }
                                }
                                element.ToWriter(writer);
                            }
                            break;
                        case HtmlFragmentType.EndElement:
                            EndElementFragment endElement = (EndElementFragment)fragment;
                            if (acceptedElementTokens.Contains(endElement.Token))
                            {
                                endElement.ToWriter(writer);
                            }
                            break;
                        case HtmlFragmentType.Text:
                            fragment.ToWriter(writer);
                            break;
                    }
                }

                return writer.ToString();
            }
        }

    }
}
