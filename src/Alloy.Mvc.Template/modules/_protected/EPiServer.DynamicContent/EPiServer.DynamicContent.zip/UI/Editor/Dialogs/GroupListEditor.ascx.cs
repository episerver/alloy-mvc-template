﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using EPiServer.Personalization.VisitorGroups;
using EPiServer.ServiceLocation;
using EPiServer.UI;
using EPiServer.Web.WebControls;

namespace EPiServer.DynamicContent.UI.Editor.Dialogs
{
    /// <summary>
    /// User control for editing personalization settings for dynamic content and personalized content
    /// </summary>
    public partial class GroupListEditor : ContentBaseUserControl
    {
        private IEnumerable<VisitorGroup> _allVisitorGroups;

        internal Injected<IVisitorGroupRepository> VisitorGroupRepository { get; set; }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!AllVisitorGroups.Any())
                {
                    NoVisitorGroupsMessage.Visible = true;
                    VisitorGroupSelection.Visible = false;
                }
                else
                {
                    NoVisitorGroupsMessage.Visible = false;
                    VisitorGroupSelection.Visible = true;
                }
            }
        }

        /// <summary>
        /// Gets or sets the group list.
        /// </summary>
        /// <value>The group list.</value>
        public string GroupList
        {
            get
            {
                return Groups.Value;
            }
            set
            {
                Groups.Value = value;
            }
        }

        /// <summary>
        /// Gets or sets the content group.
        /// </summary>
        /// <value>The content group.</value>
        public string ContentGroup
        {
            get
            {
                return ContentGroupControl.Value;
            }
            set
            {
                ContentGroupControl.Value = value;
            }
        }

        /// <summary>
        /// Sets the available content groups.
        /// </summary>
        /// <param name="allContentGroups">All content groups.</param>
        /// <param name="selectedContentGroup">The selected content group.</param>
        public void SetAvailableContentGroups(string allContentGroups, string selectedContentGroup)
        {
            // Dangerous (user) content coming in these parameters.
            // Will be attribute encoded by the input fields and encoded by the client.
            ContentGroup = selectedContentGroup;
            AllContentGroupsControl.Value = allContentGroups;
        }

        /// <summary>
        /// Creates the visitor group json.
        /// </summary>
        /// <returns></returns>
        protected string CreateVisitorGroupJson()
        {
            var value = GroupList;

            var groupIds = value.Split(',');
            var ids = new Guid[groupIds.Length];

            if (value.Length > 0)
            {
                for (var i = 0; i < groupIds.Length; i++)
                {
                    ids[i] = new Guid(groupIds[i]);
                }
            }

            var jsonList = new ArrayList();
            foreach (var group in AllVisitorGroups)
            {
                var currentlySelected = ids.FirstOrDefault(g => g == group.Id) != Guid.Empty;
                jsonList.Add(new { id = group.Id, name = group.Name, notes = group.Notes, selected = currentlySelected });
            }

            return new JavaScriptSerializer().Serialize(jsonList);
        }

        /// <summary>
        /// Gets all visitor groups.
        /// </summary>
        /// <value>All visitor groups.</value>
        private IEnumerable<VisitorGroup> AllVisitorGroups
        {
            get
            {
                if (_allVisitorGroups == null)
                {
                    _allVisitorGroups = VisitorGroupRepository.Service.List().AsQueryable().OrderBy(visitorGroup => visitorGroup.Name);
                }

                return _allVisitorGroups;
            }
        }


        /// <summary>
        /// Validates the specified is required.
        /// </summary>
        /// <param name="isRequired">if set to <c>true</c> [is required].</param>
        internal void Validate(bool isRequired)
        {
            if (isRequired)
            {
                if (string.IsNullOrEmpty(ContentGroup) && string.IsNullOrEmpty(GroupList))
                {
                    Page.Validators.Add(new StaticValidator(Translate("/edit/grouplisteditor/nocontentgrouporgrouplist")));
                }
            }

            if (noContentGroup.Checked && string.IsNullOrEmpty(ContentGroup.Trim()))
            {
                Page.Validators.Add(new StaticValidator(Translate("/edit/grouplisteditor/contentgroupcheckedbutnovalue")));
            }
        }
    }
}
