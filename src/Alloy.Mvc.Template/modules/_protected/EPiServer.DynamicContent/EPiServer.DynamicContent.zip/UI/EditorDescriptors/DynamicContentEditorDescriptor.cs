﻿using System;
using System.Collections.Generic;
using EPiServer.Core;
using EPiServer.Shell;
using EPiServer.Shell.ObjectEditing;
using EPiServer.Shell.ObjectEditing.EditorDescriptors;

namespace EPiServer.DynamicContent.EPiServer.UI.UI.EditorDescriptors
{
    [EditorDescriptorRegistration(
        TargetType = typeof(XhtmlString),
        EditorDescriptorBehavior = EditorDescriptorBehavior.PlaceLast)]
    public class DynamicContentEditorDescriptor : EditorDescriptor
    {
        private const string Key = "pluginRoutes";
        private const string PluginName = "epidynamiccontent";

        public override void ModifyMetadata(ExtendedMetadata metadata, IEnumerable<Attribute> attributes)
        {
            base.ModifyMetadata(metadata, attributes);

            var pluginRoutes = metadata.EditorConfiguration[Key] as Dictionary<string, string> ??
                               new Dictionary<string, string>();

            pluginRoutes[PluginName] = Paths.ToResource(typeof(DynamicContentEditorDescriptor), "UI/ClientResources/Editor/tiny_mce/plugins/epidynamiccontent");

            metadata.EditorConfiguration[Key] = pluginRoutes;
        }
    }
}
