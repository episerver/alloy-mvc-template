define(
"dojo/cldr/nls/sk/currency", //begin v1.x content
{
	"HKD_displayName": "Hongkongský dolár",
	"CHF_displayName": "Švajčiarský frank",
	"JPY_symbol": "JPY",
	"CAD_displayName": "Kanadský dolár",
	"HKD_symbol": "HKD",
	"CNY_displayName": "Čínsky jüan",
	"USD_symbol": "USD",
	"AUD_displayName": "Austrálsky dolár",
	"JPY_displayName": "Japonský jen",
	"CAD_symbol": "CAD",
	"USD_displayName": "Americký dolár",
	"EUR_symbol": "EUR",
	"CNY_symbol": "CNY",
	"GBP_displayName": "Britská libra",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "Euro"
}
//end v1.x content
);